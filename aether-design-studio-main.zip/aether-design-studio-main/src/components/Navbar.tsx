import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { Menu, X, Globe, ChevronDown, Search, Shield, LogIn, LogOut, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { languages } from '@/lib/i18n';
import { useAuth } from '@/hooks/useAuth';
import AuthDialog from '@/components/AuthDialog';
import logo from '@/assets/logo.png';

const Navbar = () => {
  const { t, i18n } = useTranslation();
  const { user, isAdmin, signOut, loading } = useAuth();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isLangMenuOpen, setIsLangMenuOpen] = useState(false);
  const [langSearch, setLangSearch] = useState('');
  const [showAuthDialog, setShowAuthDialog] = useState(false);
  const langMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    const handleClickOutside = (e: MouseEvent) => {
      if (langMenuRef.current && !langMenuRef.current.contains(e.target as Node)) {
        setIsLangMenuOpen(false);
        setLangSearch('');
      }
    };
    window.addEventListener('scroll', handleScroll);
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      window.removeEventListener('scroll', handleScroll);
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const changeLanguage = (code: string) => {
    i18n.changeLanguage(code);
    const lang = languages.find(l => l.code === code);
    document.documentElement.dir = lang?.rtl ? 'rtl' : 'ltr';
    document.documentElement.lang = code;
    setIsLangMenuOpen(false);
    setLangSearch('');
  };

  const handleSignOut = async () => {
    await signOut();
    setIsMobileMenuOpen(false);
  };

  const filteredLanguages = languages.filter(lang => 
    lang.name.toLowerCase().includes(langSearch.toLowerCase()) || 
    lang.code.toLowerCase().includes(langSearch.toLowerCase())
  );
  const currentLang = languages.find(l => l.code === i18n.language) || languages[0];

  const navLinks = [
    { href: '/#store', label: t('nav.store') },
    { href: '/academy', label: t('nav.academy') },
    { href: '/content-hub', label: t('nav.contentHub') },
    { href: '/resources', label: t('nav.tutorials') }
  ];

  return (
    <>
      <motion.header
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5 }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled ? 'bg-background/80 backdrop-blur-xl border-b border-white/10 py-3' : 'backdrop-blur-md bg-black/20 py-5'
        }`}
        style={{
          boxShadow: isScrolled ? '0 4px 30px rgba(0,0,0,0.3)' : 'none',
        }}
      >
        <nav className="container mx-auto px-4 flex items-center justify-between">
          {/* Logo with Dual-tone Brand Name */}
          <motion.a href="/" className="flex items-center gap-3 group" whileHover={{ scale: 1.02 }}>
            <div className="relative">
              <div className="absolute inset-0 blur-xl opacity-60">
                <img src={logo} alt="" className="h-20 w-auto" aria-hidden="true" />
              </div>
              <img 
                alt="AI DEALS" 
                src={logo} 
                className="h-20 w-auto relative z-10 drop-shadow-[0_0_20px_rgba(168,85,247,0.5)] transition-all duration-300 group-hover:drop-shadow-[0_0_35px_rgba(168,85,247,0.7)] rounded-md shadow-md" 
              />
            </div>
            
            <div className="hidden sm:flex items-baseline">
              <span 
                className="text-2xl font-display font-black tracking-tight text-primary drop-shadow-[0_0_10px_rgba(168,85,247,0.6)]" 
                style={{ textShadow: '0 0 20px hsl(var(--primary) / 0.5), 0 2px 4px rgba(0,0,0,0.3)' }}
              >
                AI
              </span>
              <span 
                className="text-2xl font-display font-black tracking-tight text-foreground ml-1" 
                style={{
                  background: 'linear-gradient(180deg, hsl(var(--foreground)) 0%, hsl(var(--muted-foreground)) 100%)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  textShadow: '0 2px 4px rgba(0,0,0,0.2)',
                  filter: 'drop-shadow(0 1px 1px rgba(255,255,255,0.1))'
                }}
              >
                DEALS
              </span>
            </div>
          </motion.a>

          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center gap-8">
            {navLinks.map(link => (
              <motion.a 
                key={link.href} 
                href={link.href} 
                className="text-muted-foreground hover:text-foreground transition-colors duration-200 relative group" 
                whileHover={{ y: -2 }}
              >
                {link.label}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-primary to-secondary group-hover:w-full transition-all duration-300" />
              </motion.a>
            ))}
          </div>

          {/* Right Section */}
          <div className="hidden lg:flex items-center gap-4">
            {/* Language Selector */}
            <div className="relative" ref={langMenuRef}>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => setIsLangMenuOpen(!isLangMenuOpen)} 
                className="flex items-center gap-2 text-muted-foreground"
              >
                <Globe className="w-4 h-4" />
                <span>{currentLang.flag}</span>
                <span className="hidden xl:inline text-xs">{currentLang.name}</span>
                <ChevronDown className={`w-4 h-4 transition-transform ${isLangMenuOpen ? 'rotate-180' : ''}`} />
              </Button>

              <AnimatePresence>
                {isLangMenuOpen && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10, scale: 0.95 }} 
                    animate={{ opacity: 1, y: 0, scale: 1 }} 
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    transition={{ type: 'spring', damping: 25, stiffness: 400 }}
                    className="absolute top-full end-0 mt-2 w-64 rounded-2xl overflow-hidden z-50"
                    style={{
                      background: 'linear-gradient(135deg, hsl(222 47% 12% / 0.98) 0%, hsl(222 47% 8% / 0.99) 100%)',
                      backdropFilter: 'blur(40px)',
                      boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5), 0 0 0 1px rgba(255, 255, 255, 0.1), 0 0 40px rgba(168, 85, 247, 0.1)',
                      border: '1px solid rgba(255, 255, 255, 0.08)',
                    }}
                  >
                    {/* Header with glassmorphism effect */}
                    <div className="p-3 border-b border-white/10" style={{ background: 'rgba(255,255,255,0.02)' }}>
                      <div className="relative">
                        <Search className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <input 
                          type="text" 
                          value={langSearch} 
                          onChange={e => setLangSearch(e.target.value)} 
                          placeholder={t('common.search')} 
                          className="w-full ps-9 pe-3 py-2.5 text-sm rounded-xl bg-white/5 border border-white/10 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20 text-foreground placeholder:text-muted-foreground transition-all" 
                          autoFocus 
                        />
                      </div>
                    </div>
                    
                    <div className="max-h-72 overflow-y-auto py-2">
                      {filteredLanguages.map((lang, index) => (
                        <motion.button 
                          key={lang.code}
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.02 }}
                          onClick={() => changeLanguage(lang.code)} 
                          className={`w-full px-4 py-3 text-start flex items-center gap-3 transition-all duration-200 ${
                            i18n.language === lang.code 
                              ? 'text-primary bg-primary/10' 
                              : 'text-foreground hover:bg-white/5'
                          }`}
                        >
                          <span className="text-xl">{lang.flag}</span>
                          <span className="flex-1 font-medium">{lang.name}</span>
                          {lang.rtl && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-primary/20 text-primary font-medium">
                              RTL
                            </span>
                          )}
                          {i18n.language === lang.code && (
                            <motion.div
                              initial={{ scale: 0 }}
                              animate={{ scale: 1 }}
                              className="w-2 h-2 rounded-full bg-primary"
                            />
                          )}
                        </motion.button>
                      ))}
                      {filteredLanguages.length === 0 && (
                        <div className="px-4 py-6 text-sm text-muted-foreground text-center">
                          {t('common.noResults')}
                        </div>
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <Button variant="heroOutline" size="sm" asChild>
              <a href="/dashboard">{t('nav.dashboard')}</a>
            </Button>

            {/* Admin Link - Only show if admin */}
            {isAdmin && (
              <Button variant="ghost" size="sm" asChild className="text-muted-foreground hover:text-foreground">
                <a href="/admin" className="flex items-center gap-1.5">
                  <Shield className="w-4 h-4" />
                  Admin
                </a>
              </Button>
            )}

            {/* Auth Buttons */}
            {!loading && (
              user ? (
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20">
                    <User className="w-4 h-4 text-primary" />
                    <span className="text-sm text-primary truncate max-w-[120px]">
                      {user.email?.split('@')[0]}
                    </span>
                  </div>
                  <Button variant="ghost" size="sm" onClick={handleSignOut} className="text-muted-foreground">
                    <LogOut className="w-4 h-4" />
                  </Button>
                </div>
              ) : (
                <Button variant="hero" size="sm" onClick={() => setShowAuthDialog(true)}>
                  <LogIn className="w-4 h-4 mr-2" />
                  {t('nav.getStarted')}
                </Button>
              )
            )}
          </div>

          {/* Mobile Menu Button */}
          <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
            {isMobileMenuOpen ? <X /> : <Menu />}
          </Button>
        </nav>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }} 
              animate={{ opacity: 1, height: 'auto' }} 
              exit={{ opacity: 0, height: 0 }} 
              className="lg:hidden glass-strong border-t border-border"
            >
              <div className="container mx-auto px-4 py-6 flex flex-col gap-4">
                {navLinks.map(link => (
                  <a 
                    key={link.href} 
                    href={link.href} 
                    className="text-lg text-muted-foreground hover:text-foreground transition-colors py-2" 
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    {link.label}
                  </a>
                ))}
                
                <div className="flex flex-wrap gap-2 pt-4 border-t border-border">
                  {languages.map(lang => (
                    <button 
                      key={lang.code} 
                      onClick={() => { changeLanguage(lang.code); setIsMobileMenuOpen(false); }} 
                      className={`px-3 py-2 rounded-lg text-sm ${
                        i18n.language === lang.code ? 'bg-primary/20 text-primary' : 'bg-muted text-muted-foreground'
                      }`}
                    >
                      {lang.flag} {lang.name}
                    </button>
                  ))}
                </div>
                
                <div className="flex flex-col gap-3 pt-4">
                  <Button variant="heroOutline" className="w-full" asChild>
                    <a href="/dashboard">{t('nav.dashboard')}</a>
                  </Button>
                  
                  {isAdmin && (
                    <Button variant="ghost" className="w-full text-muted-foreground" asChild>
                      <a href="/admin" className="flex items-center justify-center gap-2">
                        <Shield className="w-4 h-4" />
                        Admin Panel
                      </a>
                    </Button>
                  )}
                  
                  {!loading && (
                    user ? (
                      <Button variant="ghost" className="w-full" onClick={handleSignOut}>
                        <LogOut className="w-4 h-4 mr-2" />
                        Sign Out
                      </Button>
                    ) : (
                      <Button variant="hero" className="w-full" onClick={() => { setShowAuthDialog(true); setIsMobileMenuOpen(false); }}>
                        <LogIn className="w-4 h-4 mr-2" />
                        {t('nav.getStarted')}
                      </Button>
                    )
                  )}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.header>

      <AuthDialog open={showAuthDialog} onOpenChange={setShowAuthDialog} />
    </>
  );
};

export default Navbar;